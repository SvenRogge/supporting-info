#!/usr/bin/env python

import os, sys
import numpy as np
import h5py
import ctypes
from mpi4py import MPI
from glob import glob

from yaff import System, ForceField, HDF5Writer, RestartWriter, XYZWriter,\
    NHCThermostat, MTKBarostat, TBCombination, VerletScreenLog, VerletIntegrator, log,\
    PairPotLJ, PairPotMM3, ForcePartPair, write_lammps_table, ForcePartLammps
from molmod.units import *
from yaff.log import log, timer
from yaff.external.lammpsio import *
from yaff.pes import *
from yaff.sampling.utils import cell_lower

from ghostatoms import GhostForceField

def get_ff(rcut=12.0*angstrom, dotail=True):
    # Load initial system
    system = System.from_file('init.chk')
    # Construct force field
    ff_fns = ['pars.txt']
    ff = ForceField.generate(system, ff_fns, rcut=rcut, alpha_scale=3.2, gcut_scale=1.5, tailcorrections=dotail)
    # Get the indexes of the ghost atoms (M atoms of TIP4P water)
    ghost_indexes = np.array([iatom for iatom in range(system.natom) if system.get_ffatype(iatom)=='TM'])
    ghostff = GhostForceField(ff, ghost_indexes, write_ghost_pos, write_ghost_gpos)
    return ghostff

def write_ghost_pos(system, ghost_indexes):
    '''
    Update M site position of TIP4P water based on position of other atoms in molecule
    Assumes that atoms are always ordered as O-H-H-M

        r_M = r_O + d_OM^rel/2 * [ (1+d02/d01)*r01 + (1+d01/d02)*r02 ]
    '''
    d_om_rel = 0.13194
    for iatom in ghost_indexes:
        # Vector pointing from O to H1
        r01 = system.pos[iatom-1] - system.pos[iatom-3]
        system.cell.mic(r01)
        d01 = np.linalg.norm(r01)
        # Vector pointing from O to H2
        r02 = system.pos[iatom-2] - system.pos[iatom-3]
        system.cell.mic(r02)
        d02 = np.linalg.norm(r02)
        # Set M position
        system.pos[iatom] = system.pos[iatom-3] + 0.5*d_om_rel*((1.0+d02/d01)*r01 + (1.0+d01/d02)*r02)

def write_ghost_gpos(gpos, vtens, system, ghost_indexes):
    d_om_rel = 0.13194
    for iatom in ghost_indexes:
        # Vector pointing from O to H1
        r01 = system.pos[iatom-1] - system.pos[iatom-3]
        system.cell.mic(r01)
        d01 = np.linalg.norm(r01)
        # Vector pointing from O to H2
        r02 = system.pos[iatom-2] - system.pos[iatom-3]
        system.cell.mic(r02)
        d02 = np.linalg.norm(r02)
        # Partial derivatives of M positions
        pdiff_01 = gpos[iatom,:]*(1.0+d02/d01) - r01*np.dot(gpos[iatom,:],(d02/d01/d01/d01*r01-r02/d01/d02))
        pdiff_02 = gpos[iatom,:]*(1.0+d01/d02) - r02*np.dot(gpos[iatom,:],(d01/d02/d02/d02*r02-r01/d02/d01))
        # Apply chain rule
        gpos[iatom-3,:] += gpos[iatom,:]
        gpos[iatom-3,:] -= 0.5*d_om_rel*pdiff_01
        gpos[iatom-3,:] -= 0.5*d_om_rel*pdiff_02
        gpos[iatom-1,:] += 0.5*d_om_rel*pdiff_01
        gpos[iatom-2,:] += 0.5*d_om_rel*pdiff_02
        if vtens is not None:
            r_mo = 0.5*d_om_rel*((1.0+d02/d01)*r01 + (1.0+d01/d02)*r02)
            vtens[:] -= np.outer(gpos[iatom],r_mo)
            vtens[:] += np.outer(0.5*d_om_rel*pdiff_01,r01)
            vtens[:] += np.outer(0.5*d_om_rel*pdiff_02,r02)

class ForcePartLammps2(ForcePartLammps):
    def update_pos(self, pos):
        '''
        Update the LAMMPS positions based on the coordinates from Yaff
        '''
        # Perform the rotation
        pos[:] = np.einsum('ij,kj', pos, self.rot)
        # TODO: check if mic is necessary or not
        for i in range(self.system.natom):
            self.cell.mic(pos[i])
        x = self.lammps.gather_atoms("x",1,3)
        for i in range(3*self.system.natom):
            x[i] = pos[i//3,i%3]
        #self.lammps.scatter_atoms("x",1,3,x)
        self.lammps.scatter_atoms("x",1,3,ctypes.c_void_p(pos.ctypes.data))

def swap_noncovalent_lammps2(ff, **kwargs):
    r'''Take a YAFF ForceField instance and replace noncovalent interactions with
    a ForcePartLammps instance.

           **Arguments:**

           ff
                a YAFF ForceField instance

           **Optional arguments:**

           fn_system
                The filename to which the system data in LAMMPS format will be
                written.

           overwrite_table
                whether or not fn_table should be updated if it already exists.
                Default is ``False``

           nrows
                The number of rows to use for tabulating noncovalent
                interactions. Default is 5000

           keep_forceparts
                classes of ForceParts present in this list will be retained
                in the YAFF ForceField and will not be included in the
                tabulated interactions. Typically this will be covalent
                interactions, but also for instance analytical tail
                corrections. Default:[ForcePartTailCorrection,ForcePartGrid,
                ForcePartPressure,ForcePartValence]

           Any optional argument in the constructor of the
                :class:`yaff.external.liblammps.ForcePartLammps` class,
                can be passed here as well.
    '''
    # Some keyword arguments that should not be passed to the constructor of
    # ForcePartLammps
    overwrite_table = kwargs.pop("overwrite_table", False)
    nrows = kwargs.pop("nrows", 5000)
    keep_forceparts = kwargs.pop("keep_forceparts", [ForcePartTailCorrection,
        ForcePartGrid, ForcePartPressure, ForcePartValence])
    fn_system = kwargs.pop("fn_system", "system.dat")
    # Some other keywords that should be passed to ForcePartLammps
    comm = kwargs.get("comm", None)
    fn_table = kwargs.get("fn_table", "lammps.table")
    triclinic = kwargs.get("triclinic", True)
    # Find out which parts need to be retained, and which ones need to be tabulated
    parts, parts_tabulated = [],[]
    scaling_rules = [1.0,1.0,1.0,1.0]
    correct_15_rule = False
    do_table, do_ei = False, False
    for part in ff.parts:
        if part.__class__ in keep_forceparts:
            parts.append(part)
        else:
            parts_tabulated.append(part)
        # LAMMPS will use the ``strongest'' scaling rules, i.e. following the
        # part that sets most nearest neighbors interactions to zero.
        # Corrections for this are applied afterwards
        if part.__class__==ForcePartPair:
            if part.scalings.scale1!=1.0: scaling_rules[0]=0.0
            if part.scalings.scale2!=1.0: scaling_rules[1]=0.0
            if part.scalings.scale3!=1.0: scaling_rules[2]=0.0
            if part.scalings.scale4!=1.0:
                correct_15_rule = True
            # Check whether electrostatics and/or tables need to be included by LAMMPS
            if part.name=='pair_ei':
                do_ei = True
                # Corrections to electrostatic interactions for Gaussian
                # are included in the table
                if np.any(part.pair_pot.radii!=0.0): do_table=True
            else: do_table = True
    # Generate tables (if necessary) for force field containing relevant parts
    if not os.path.isfile(fn_table) or overwrite_table:
        # Make sure that at most one process actually writes the table
        if comm is None or comm.Get_rank()==0:
            ff_tabulate = ForceField(ff.system, parts_tabulated, nlist=ff.nlist)
            write_lammps_table(ff_tabulate,fn=fn_table, nrows=nrows)
        # Let all processes wait untill the table is completely written
        if comm is not None: comm.Barrier()
    # Write system data
    # Make sure that at most one process writes the data file
    if comm is None or comm.Get_rank()==0:
        write_lammps_system_data(ff.system, ff=ff, fn=fn_system, triclinic=triclinic)
    # Let all processes wait untill the data file is completely written
    if comm is not None: comm.Barrier()
    # Adapt optional arguments
    kwargs["scalings_ei"] = np.array(scaling_rules)
    kwargs["do_ei"] = do_ei
    kwargs["scalings_table"] = np.array(scaling_rules)
    kwargs["do_table"] = do_table
    # Get the ForcePartLammps, which will handle noncovalent interactions
    part_lammps = ForcePartLammps2(ff, fn_system, **kwargs)
    parts.append(part_lammps)
    # Potentially add additional parts which correct scaling rules
    scaling_nlist = BondedNeighborList(ff.system,selected=[],add15=correct_15_rule)
    nlist = None
    for part in ff.parts:
        if part.__class__==ForcePartPair:
            part_scalings = np.array([part.scalings.scale1,part.scalings.scale2,part.scalings.scale3,part.scalings.scale4])
            if np.any(part_scalings!=scaling_rules):
                scale4 = part_scalings[3]-1.0 if correct_15_rule else 1.0
                correction_scalings = Scalings(ff.system,scale1=part_scalings[0]-scaling_rules[0],
                    scale2=part_scalings[1]-scaling_rules[1],scale3=part_scalings[2]-scaling_rules[2],scale4=scale4)
                # Electrostatics: special case, because now alpha should be zero
                if part.name=='pair_ei':
                    pair_correction = PairPotEI(ff.system.charges, 0.0, rcut=part.pair_pot.rcut,
                        tr=part.pair_pot.get_truncation(), dielectric=part.pair_pot.dielectric,
                        radii=part.pair_pot.radii.copy())
                    part_correction = ForcePartPair(ff.system, scaling_nlist, correction_scalings, pair_correction)
                else:
                    part_correction = ForcePartPair(ff.system, scaling_nlist, correction_scalings, part.pair_pot)
                parts.append(part_correction)
                nlist = scaling_nlist
    # Construct the new force field
    ff_lammps = ForceField(ff.system, parts, nlist=nlist)
    return ff_lammps


if __name__=='__main__':
    # Setup MPI
    comm = MPI.COMM_WORLD
    rank = comm.Get_rank()

    # Set random seed, important to get the same velocities for all processes
    np.random.seed(111)

    # Turn off logging for all processes, it can be turned on for one selected process later on
    log.set_level(log.silent)
    if rank==0: log.set_level(log.medium)

    # General settings
    rcut = 12.0*angstrom
    dotail = True

    # Load initial system
    system = System.from_file('init.chk')
    # Construct force field
    ff_fns = ['pars.txt']
    ff = ForceField.generate(system, ff_fns, rcut=rcut, alpha_scale=3.2, gcut_scale=1.5, tailcorrections=dotail)
    # Get the indexes of the ghost atoms (M atoms of TIP4P water)
    ghost_indexes = np.array([iatom for iatom in range(system.natom) if system.get_ffatype(iatom)=='TM'])

    # Call separately write_lammps_table to make minimal r to 0.10 A and make ghost LAMMPS force field
    #write_lammps_table(ff, fn='rcut_12.0.table', rmin=0.10*angstrom, nrows=7500, unit_style='electron')
    ff_lammps = swap_noncovalent_lammps2(ff, fn_system='lammps.dat', suffix='', fn_table='rcut_12.0.table', overwrite_table=False, comm=comm)

    ghostff = GhostForceField(ff_lammps, ghost_indexes, write_ghost_pos, write_ghost_gpos)

    # Only write output from process 0
    if rank==0:
        f = h5py.File('traj_1.h5', mode='w')
        hdf = HDF5Writer(f, step=1000)
        g = h5py.File('restart_1.h5',mode='w')
        hdf_restart = RestartWriter(g, step=100000)

    # Prepare MD run
    timestep = 0.5*femtosecond
    temp = 300*kelvin
    press=0e6*pascal

    thermo = NHCThermostat(temp, timecon=100.0*femtosecond, chainlength=3)
    baro = MTKBarostat(ghostff, temp, press, timecon=1000.0*femtosecond, vol_constraint=False,anisotropic=True)
    TBC = TBCombination(thermo, baro)
    vsl = VerletScreenLog(step=10000)

    # Only write output from process 0
    if rank==0:
        log.set_level(log.medium)
        hooks = [hdf,hdf_restart,TBC,vsl]
    else:
        log.set_level(log.silent)
        hooks = [TBC,vsl]

    md = VerletIntegrator(ghostff, timestep, hooks=hooks)

    # Initial check
    print('Yaff+LAMMPS energy')
    print(ghostff.compute()/kjmol)
    for part in ghostff.ff.parts:
        print('%s: %.3f kJ/mol' %(part.name,part.energy/kjmol))
    
    # Actual MD run
    md.run(200000)
